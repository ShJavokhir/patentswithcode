
# Simple Python Calculator

A basic calculator with add, subtract, multiply, and divide functions.

## Usage
Run `python main.py` to start the interactive calculator.
