
from calculator import add, subtract, multiply, divide

def main():
    try:
        print("Simple Calculator")
        while True:
            print("
Choose operation:")
            print("1. Add")
            print("2. Subtract")
            print("3. Multiply")
            print("4. Divide")
            print("5. Exit")

            choice = input("Enter choice (1-5): ")

            if choice == '5':
                print("Exiting calculator...")
                break

            if choice not in ['1', '2', '3', '4']:
                print("Invalid input. Try again.")
                continue

            try:
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))
            except ValueError:
                print("Invalid number input. Try again.")
                continue

            try:
                if choice == '1':
                    result = add(num1, num2)
                    print(f"{num1} + {num2} = {result}")
                elif choice == '2':
                    result = subtract(num1, num2)
                    print(f"{num1} - {num2} = {result}")
                elif choice == '3':
                    result = multiply(num1, num2)
                    print(f"{num1} * {num2} = {result}")
                elif choice == '4':
                    result = divide(num1, num2)
                    print(f"{num1} / {num2} = {result}")

            except ValueError as e:
                print(f"Error: {e}")

if __name__ == '__main__':
    main()
