import React, { useState } from 'react';
import styled from 'styled-components';

const CalculatorContainer = styled.div`
  max-width: 300px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
`;

const InputContainer = styled.div`
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
`;

const Input = styled.input`
  flex: 1;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
`;

const Button = styled.button`
  padding: 8px 15px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  
  &:hover {
    background-color: #45a049;
  }
`;

const ResultDisplay = styled.div`
  font-size: 18px;
  font-weight: bold;
  margin-top: 15px;
`;

const Calculator: React.FC = () => {
  const [num1, setNum1] = useState<string>('');
  const [num2, setNum2] = useState<string>('');
  const [result, setResult] = useState<number | null>(null);

  const add = () => {
    setResult(Number(num1) + Number(num2));
  };

  const subtract = () => {
    setResult(Number(num1) - Number(num2));
  };

  const multiply = () => {
    setResult(Number(num1) * Number(num2));
  };

  const divide = () => {
    setResult(Number(num1) / Number(num2));
  };

  return (
    <CalculatorContainer>
      <InputContainer>
        <Input 
          type="number" 
          value={num1} 
          onChange={(e) => setNum1(e.target.value)} 
          placeholder="Number 1" 
        />
        <Input 
          type="number" 
          value={num2} 
          onChange={(e) => setNum2(e.target.value)} 
          placeholder="Number 2" 
        />
      </InputContainer>
      <InputContainer>
        <Button onClick={add}>+</Button>
        <Button onClick={subtract}>-</Button>
        <Button onClick={multiply}>*</Button>
        <Button onClick={divide}>/</Button>
      </InputContainer>
      {result !== null && (
        <ResultDisplay>Result: {result}</ResultDisplay>
      )}
    </CalculatorContainer>
  );
};

export default Calculator;
