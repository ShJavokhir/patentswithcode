import datetime

def main():
    print('Hello, World!')
    print(f'Current date: {datetime.date.today()}')

if __name__ == '__main__':
    main()
