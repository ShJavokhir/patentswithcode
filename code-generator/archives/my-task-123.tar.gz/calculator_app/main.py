
from calculator import Calculator

def main():
    try:
        # Example usage
        print("Calculator Operations:")
        print(f"Addition: 5 + 3 = {Calculator.add(5, 3)}")
        print(f"Subtraction: 10 - 4 = {Calculator.subtract(10, 4)}")
        print(f"Multiplication: 6 * 7 = {Calculator.multiply(6, 7)}")
        print(f"Division: 15 / 3 = {Calculator.divide(15, 3)}")
        
        # Demonstrate error handling
        try:
            print(f"Division by Zero: {Calculator.divide(10, 0)}")
        except ValueError as e:
            print(f"Error: {e}")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == '__main__':
    main()
