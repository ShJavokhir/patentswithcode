
from calculator import add, subtract, multiply, divide

def main():
    try:
        # Example usage
        print("Addition: ", add(5, 3))
        print("Subtraction: ", subtract(10, 4))
        print("Multiplication: ", multiply(6, 2))
        print("Division: ", divide(15, 3))
        
        # Demonstrate error handling
        try:
            divide(10, 0)
        except ValueError as e:
            print("Error:", str(e))
    
    except Exception as e:
        print("An unexpected error occurred:", str(e))

if __name__ == '__main__':
    main()
