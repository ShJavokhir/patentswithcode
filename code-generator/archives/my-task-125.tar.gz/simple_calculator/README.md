# Simple Calculator

A basic calculator with add, subtract, multiply, and divide functions.

## Usage
Run main.py to see example calculations.
