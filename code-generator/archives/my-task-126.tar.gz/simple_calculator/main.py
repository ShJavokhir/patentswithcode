
from calculator import add, subtract, multiply, divide

def main():
    try:
        # Example operations
        print(f"10 + 5 = {add(10, 5)}")
        print(f"10 - 5 = {subtract(10, 5)}")
        print(f"10 * 5 = {multiply(10, 5)}")
        print(f"10 / 5 = {divide(10, 5)}")
        print(f"10 / 0 = {divide(10, 0)}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
