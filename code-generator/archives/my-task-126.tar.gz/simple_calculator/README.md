# Simple Calculator

A basic Python calculator with add, subtract, multiply, and divide functions.

## Usage

Run `python main.py` to see example calculations.
