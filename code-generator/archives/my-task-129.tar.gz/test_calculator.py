from calculator import add, subtract, multiply, divide

def test_calculator():
    assert add(2, 3) == 5
    assert subtract(5, 3) == 2
    assert multiply(4, 3) == 12
    assert divide(6, 2) == 3
    
    try:
        divide(5, 0)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

if __name__ == "__main__":
    test_calculator()
    print("All tests passed!")
